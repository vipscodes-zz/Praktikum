package ac.ifunpas.kplbo.uts.avipsyaifulloh;

public class Mobil {
	// Nama : Avip Syaifulloh
	// NRP : 183040024
	private String noPol;
	private String merk;
	private int jmlBahanBakar;
	
	public String getNoPol() {
		return noPol;
	}
	public void setNoPol(String noPol) {
		this.noPol = noPol;
	}
	public String getMerk() {
		return merk;
	}
	public void setMerk(String merk) {
		this.merk = merk;
	}
	public int getJmlBahanBakar() {
		return jmlBahanBakar;
	}
	public void setJmlBahanBakar(int jmlBahanBakar) {
		this.jmlBahanBakar = jmlBahanBakar;
	}
	
	
	
}
