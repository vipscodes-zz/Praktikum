package latihan6;

public class ListTest {
	public static void main(String[] args) {
		List ls = new List();
		
//		ls.addHead(5);
//		ls.addHead(4);
//		ls.addHead(3);
//		ls.displayElement();
		
		ls.addHead(7);
		ls.addHead(1);
		ls.addHead(2);
		ls.addHead(3);
		ls.displayElement();
	}
}
