package tugas;

public class ListTest2 {
	public static void main(String[] args) {
		List ls = new List();
//		ls.addHead(2);
//		ls.addTail(1);
//		ls.addHead(5);
//		ls.addTail(3);
//		ls.displayElement();
		
		ls.addHead(2);
		ls.addTail(1);
		ls.addHead(5);
		ls.addTail(3);
		ls.addHead(3);
		ls.addTail(7);
		ls.displayElement();
	}
}
